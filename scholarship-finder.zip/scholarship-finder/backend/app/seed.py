from app.database import SessionLocal, engine
from app.models import Base, Opportunity
from datetime import datetime, timedelta

def seed_opportunities():
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()

    existing = db.query(Opportunity).first()
    if existing:
        db.close()
        return

    opportunities = [
        Opportunity(
            title="DAAD Scholarship",
            organization="German Academic Exchange Service",
            type="scholarship",
            field="Any",
            degree_levels=["masters", "phd"],
            countries=["All"],
            amount="€850-1,200/month + insurance + travel",
            deadline=datetime(2026, 10, 15),
            description="Fully-funded postgraduate scholarships for international students to study in Germany. Covers living expenses, health insurance, and travel allowance.",
            requirements="Bachelor's degree, 2+ years work experience preferred, strong academic record",
            url="https://www.daad.de/en/study-and-research-in-germany/scholarships/",
            tags=["fully-funded", "germany", "international"]
        ),
        Opportunity(
            title="Fulbright Foreign Student Program",
            organization="U.S. Department of State",
            type="fellowship",
            field="Any",
            degree_levels=["masters", "phd"],
            countries=["All"],
            amount="Full tuition + stipend + health insurance",
            deadline=datetime(2026, 9, 1),
            description="Prestigious fellowship for graduate study and research in the United States. One of the most competitive international exchange programs.",
            requirements="Bachelor's degree, strong academic/professional record, leadership potential, English proficiency",
            url="https://foreign.fulbrightonline.org/",
            tags=["usa", "prestigious", "fully-funded", "leadership"]
        ),
        Opportunity(
            title="Google STEP Internship",
            organization="Google",
            type="internship",
            field="Computer Science",
            degree_levels=["undergrad"],
            countries=["USA", "Canada", "EMEA"],
            amount="$7,000-9,000/month + housing stipend",
            deadline=datetime(2026, 11, 30),
            description="First-year and second-year student internship program at Google. Designed for students from underrepresented groups in tech.",
            requirements="Currently enrolled in BA/BS program, basic programming skills (Python, Java, C++), interest in software engineering",
            url="https://buildyourfuture.withgoogle.com/programs/step",
            tags=["tech", "google", "software-engineering", "diversity"]
        ),
        Opportunity(
            title="MIT PRIMES Research Program",
            organization="MIT",
            type="research",
            field="Mathematics / CS / Computational Biology",
            degree_levels=["high_school", "undergrad"],
            countries=["USA"],
            amount="Free research mentorship + potential stipend",
            deadline=datetime(2026, 11, 15),
            description="Year-long research program for high school students mentored by MIT graduate students and faculty. Leads to original research publications.",
            requirements="High school student in MA or nearby, strong math background, ability to work independently",
            url="https://math.mit.edu/research/highschool/primes/",
            tags=["research", "mit", "mathematics", "publication"]
        ),
        Opportunity(
            title="Rhodes Scholarship",
            organization="Rhodes Trust",
            type="scholarship",
            field="Any",
            degree_levels=["masters", "phd"],
            countries=["USA", "Canada", "Australia", "India", "Germany", "Hong Kong", "China", "UAE", "Singapore", "Malaysia", "South Africa", "Zambia", "Zimbabwe", "Pakistan", "Jamaica", "Bermuda"],
            amount="Full tuition + £18,000/year stipend",
            deadline=datetime(2026, 10, 1),
            description="World's oldest and most prestigious international scholarship for graduate study at Oxford University. Seeks young leaders with academic excellence, energy, and commitment to service.",
            requirements="Age 18-24, bachelor's degree, outstanding academic record, leadership, character, commitment to service",
            url="https://www.rhodeshouse.ox.ac.uk/",
            tags=["oxford", "prestigious", "leadership", "fully-funded"]
        ),
        Opportunity(
            title="UNSW Research Scholarship",
            organization="University of New South Wales",
            type="scholarship",
            field="STEM",
            degree_levels=["phd", "masters"],
            countries=["All"],
            amount="AUD $35,000/year + tuition waiver",
            deadline=datetime(2026, 9, 30),
            description="Competitive research scholarships for domestic and international students pursuing postgraduate research at UNSW Sydney.",
            requirements="Honours degree or equivalent, strong research proposal, supervisor agreement",
            url="https://www.unsw.edu.au/research/hdr",
            tags=["australia", "stem", "research", "phd"]
        ),
        Opportunity(
            title="Microsoft Explore Internship",
            organization="Microsoft",
            type="internship",
            field="Computer Science / Software Engineering",
            degree_levels=["undergrad"],
            countries=["USA", "Canada", "India", "Ireland", "UK"],
            amount="$8,000-10,000/month + housing + relocation",
            deadline=datetime(2026, 10, 15),
            description="12-week summer internship for first/second-year students. Rotational program through software engineering, program management, and product design.",
            requirements="Currently enrolled in CS or related field, intro programming courses completed, passion for technology",
            url="https://careers.microsoft.com/students/us/en/us-intern-explore",
            tags=["tech", "microsoft", "software-engineering", "rotational"]
        ),
        Opportunity(
            title="Gates Cambridge Scholarship",
            organization="Bill & Melinda Gates Foundation",
            type="scholarship",
            field="Any",
            degree_levels=["masters", "phd"],
            countries=["All (non-UK)"],
            amount="Full cost + discretionary funding",
            deadline=datetime(2026, 10, 15),
            description="Full-cost scholarship for postgraduate study at Cambridge. Seeks outstanding applicants with leadership capacity and commitment to improving lives.",
            requirements="Bachelor's degree, outstanding academic record, leadership, commitment to improving lives of others",
            url="https://www.gatescambridge.org/",
            tags=["cambridge", "prestigious", "leadership", "fully-funded"]
        ),
        Opportunity(
            title="Meta University Internship",
            organization="Meta",
            type="internship",
            field="Computer Science / Engineering",
            degree_levels=["undergrad"],
            countries=["USA"],
            amount="$8,500-10,000/month + housing",
            deadline=datetime(2026, 11, 1),
            description="10-12 week internship for students from underrepresented backgrounds in tech. Hands-on software engineering experience at Meta.",
            requirements="Currently enrolled in CS/related field, programming experience, underrepresented group in tech",
            url="https://www.metacareers.com/students/",
            tags=["tech", "meta", "diversity", "software-engineering"]
        ),
        Opportunity(
            title="ETH Zurich Excellence Scholarship",
            organization="ETH Zurich",
            type="scholarship",
            field="STEM",
            degree_levels=["masters"],
            countries=["All"],
            amount="CHF 12,000/semester + tuition waiver",
            deadline=datetime(2026, 12, 15),
            description="Merit-based scholarship for outstanding students pursuing Master's degrees at ETH Zurich. One of Europe's top technical universities.",
            requirements="Bachelor's degree with top grades, strong motivation letter, academic excellence",
            url="https://ethz.ch/students/en/studies/non-degree-courses/excellence-scholarship-opportunity-programme.html",
            tags=["switzerland", "stem", "merit-based", "masters"]
        ),
        Opportunity(
            title="Amgen Scholars Program",
            organization="Amgen Foundation",
            type="research",
            field="Biology / Biochemistry / Biotech",
            degree_levels=["undergrad"],
            countries=["USA", "Europe", "Japan", "Australia", "Canada"],
            amount="$4,000-6,000 stipend + housing + travel",
            deadline=datetime(2026, 2, 1),
            description="Summer research program for undergraduates in biotechnology and biomedical sciences. Conduct research at top institutions with faculty mentors.",
            requirements="Sophomore/junior standing, biology/chemistry interest, minimum GPA 3.2",
            url="https://amgenscholars.com/",
            tags=["biotech", "research", "summer", "undergrad"]
        ),
        Opportunity(
            title="Schwarzman Scholars",
            organization="Schwarzman Foundation",
            type="fellowship",
            field="Any",
            degree_levels=["masters"],
            countries=["All"],
            amount="Full tuition + room/board + travel + stipend",
            deadline=datetime(2026, 9, 15),
            description="One-year Master's program at Tsinghua University in Beijing focused on leadership, China, and global affairs. Fully funded for future leaders.",
            requirements="Bachelor's degree, age 18-28, leadership record, English proficiency, interest in China/global affairs",
            url="https://www.schwarzmanscholars.org/",
            tags=["china", "leadership", "global-affairs", "fully-funded"]
        ),
        Opportunity(
            title="NSF Graduate Research Fellowship",
            organization="National Science Foundation",
            type="fellowship",
            field="STEM / Social Sciences",
            degree_levels=["undergrad", "masters", "phd"],
            countries=["USA"],
            amount="$37,000/year + $12,000 education allowance",
            deadline=datetime(2026, 10, 18),
            description="Prestigious fellowship supporting graduate students in NSF-supported STEM and social science disciplines. Three years of funding.",
            requirements="US citizen/national/permanent resident, early graduate student, strong research proposal",
            url="https://www.nsfgrfp.org/",
            tags=["usa", "stem", "research", "federal"]
        ),
        Opportunity(
            title="Palantir Future Scholarship",
            organization="Palantir",
            type="scholarship",
            field="Computer Science / Data Science",
            degree_levels=["undergrad"],
            countries=["USA", "Canada", "UK"],
            amount="$7,000 + mentorship + interview prep",
            deadline=datetime(2026, 3, 15),
            description="Scholarship for students from underrepresented backgrounds in tech. Includes mentorship, interview preparation, and potential internship opportunities.",
            requirements="CS/DS major, underrepresented background, strong academic record, interest in data/technology",
            url="https://www.palantir.com/careers/",
            tags=["tech", "diversity", "data-science", "mentorship"]
        ),
        Opportunity(
            title="CERN Summer Student Program",
            organization="CERN",
            type="research",
            field="Physics / Engineering / CS",
            degree_levels=["undergrad", "masters"],
            countries=["All (CERN member/non-member states)"],
            amount="CHF 90/day + travel allowance",
            deadline=datetime(2026, 1, 26),
            description="Summer research program at CERN, the world's largest particle physics laboratory. Work on cutting-edge physics and engineering projects.",
            requirements="Physics/engineering/CS student, completed at least 3 years of study, strong physics/math background",
            url="https://careers.smartrecruiters.com/CERN/summer-student",
            tags=["physics", "research", "switzerland", "cern"]
        ),
    ]

    db.add_all(opportunities)
    db.commit()
    db.close()
    print(f"Seeded {len(opportunities)} opportunities")

if __name__ == "__main__":
    seed_opportunities()
