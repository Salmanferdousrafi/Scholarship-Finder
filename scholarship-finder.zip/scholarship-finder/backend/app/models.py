from sqlalchemy import Column, Integer, String, Float, DateTime, Text, Boolean, ForeignKey, JSON
from sqlalchemy.orm import relationship
from app.database import Base
from datetime import datetime

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, index=True)
    email = Column(String, unique=True, index=True)
    name = Column(String)
    field_of_study = Column(String)
    degree_level = Column(String)  # undergrad, masters, phd, postdoc
    country = Column(String)
    gpa = Column(Float, nullable=True)
    skills = Column(JSON, default=list)
    experience = Column(Text, nullable=True)
    budget_need = Column(Boolean, default=False)
    deadline_window_months = Column(Integer, default=12)
    created_at = Column(DateTime, default=datetime.utcnow)

    applications = relationship("Application", back_populates="user")

class Opportunity(Base):
    __tablename__ = "opportunities"
    id = Column(Integer, primary_key=True, index=True)
    title = Column(String, index=True)
    organization = Column(String)
    type = Column(String)  # scholarship, internship, fellowship, research
    field = Column(String)
    degree_levels = Column(JSON)  # ["undergrad", "masters"]
    countries = Column(JSON)  # eligible countries
    amount = Column(String, nullable=True)
    deadline = Column(DateTime, nullable=True)
    description = Column(Text)
    requirements = Column(Text)
    url = Column(String)
    is_verified = Column(Boolean, default=True)
    tags = Column(JSON, default=list)
    created_at = Column(DateTime, default=datetime.utcnow)

    applications = relationship("Application", back_populates="opportunity")

class Application(Base):
    __tablename__ = "applications"
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    opportunity_id = Column(Integer, ForeignKey("opportunities.id"))
    status = Column(String, default="interested")  # interested, applied, accepted, rejected
    notes = Column(Text, nullable=True)
    applied_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    user = relationship("User", back_populates="applications")
    opportunity = relationship("Opportunity", back_populates="applications")
