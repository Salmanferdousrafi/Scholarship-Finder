from pydantic import BaseModel, Field
from typing import List, Optional
from datetime import datetime

class OpportunityBase(BaseModel):
    title: str
    organization: str
    type: str
    field: str
    degree_levels: List[str]
    countries: List[str]
    amount: Optional[str] = None
    deadline: Optional[datetime] = None
    description: str
    requirements: Optional[str] = None
    url: str
    tags: List[str] = []

class OpportunityCreate(OpportunityBase):
    pass

class OpportunityOut(OpportunityBase):
    id: int
    is_verified: bool
    created_at: datetime

    class Config:
        from_attributes = True

class UserBase(BaseModel):
    email: str
    name: str
    field_of_study: str
    degree_level: str
    country: str
    gpa: Optional[float] = None
    skills: List[str] = []
    experience: Optional[str] = None
    budget_need: bool = False
    deadline_window_months: int = 12

class UserCreate(UserBase):
    pass

class UserOut(UserBase):
    id: int
    created_at: datetime

    class Config:
        from_attributes = True

class MatchResult(BaseModel):
    opportunity: OpportunityOut
    score: float = Field(..., ge=0, le=100)
    explanation: str
    key_fit_factors: List[str]

class ResumeParseOut(BaseModel):
    name: Optional[str] = None
    field_of_study: Optional[str] = None
    degree_level: Optional[str] = None
    gpa: Optional[float] = None
    skills: List[str] = []
    experience_summary: Optional[str] = None
    raw_text: str

class ApplicationCreate(BaseModel):
    opportunity_id: int
    status: str = "interested"
    notes: Optional[str] = None

class ApplicationOut(BaseModel):
    id: int
    user_id: int
    opportunity_id: int
    status: str
    notes: Optional[str]
    applied_at: Optional[datetime]
    created_at: datetime
    opportunity: OpportunityOut

    class Config:
        from_attributes = True
