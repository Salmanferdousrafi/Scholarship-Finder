from fastapi import FastAPI, Depends, HTTPException, UploadFile, File, Query
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from typing import List, Optional
from datetime import datetime
import os

from app.database import engine, get_db
from app.models import Base, User, Opportunity, Application
from app.schemas import (
    UserCreate, UserOut, OpportunityOut, MatchResult,
    ResumeParseOut, ApplicationCreate, ApplicationOut
)
from app.seed import seed_opportunities
from app.resume_parser import parse_resume
from app.matching import match_opportunities

# Create tables and seed
Base.metadata.create_all(bind=engine)
seed_opportunities()

app = FastAPI(title="AI Scholarship & Internship Finder", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ========== HEALTH ==========
@app.get("/health")
def health():
    return {"status": "ok", "version": "1.0.0", "seeded": True}

# ========== USERS ==========
@app.post("/users", response_model=UserOut)
def create_user(user: UserCreate, db: Session = Depends(get_db)):
    existing = db.query(User).filter(User.email == user.email).first()
    if existing:
        raise HTTPException(status_code=400, detail="Email already registered")
    db_user = User(**user.model_dump())
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    return db_user

@app.get("/users/{user_id}", response_model=UserOut)
def get_user(user_id: int, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return user

@app.put("/users/{user_id}", response_model=UserOut)
def update_user(user_id: int, user_update: UserCreate, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    for key, value in user_update.model_dump().items():
        setattr(user, key, value)
    db.commit()
    db.refresh(user)
    return user

# ========== OPPORTUNITIES ==========
@app.get("/opportunities", response_model=List[OpportunityOut])
def list_opportunities(
    type: Optional[str] = Query(None),
    field: Optional[str] = Query(None),
    degree_level: Optional[str] = Query(None),
    search: Optional[str] = Query(None),
    db: Session = Depends(get_db)
):
    query = db.query(Opportunity)
    if type:
        query = query.filter(Opportunity.type == type)
    if field:
        query = query.filter(Opportunity.field.ilike(f"%{field}%"))
    if degree_level:
        query = query.filter(Opportunity.degree_levels.contains([degree_level]))
    if search:
        query = query.filter(
            Opportunity.title.ilike(f"%{search}%") |
            Opportunity.organization.ilike(f"%{search}%") |
            Opportunity.description.ilike(f"%{search}%")
        )
    return query.all()

@app.get("/opportunities/{opp_id}", response_model=OpportunityOut)
def get_opportunity(opp_id: int, db: Session = Depends(get_db)):
    opp = db.query(Opportunity).filter(Opportunity.id == opp_id).first()
    if not opp:
        raise HTTPException(status_code=404, detail="Opportunity not found")
    return opp

# ========== RESUME PARSING ==========
@app.post("/parse-resume", response_model=ResumeParseOut)
async def parse_resume_endpoint(file: UploadFile = File(...)):
    contents = await file.read()
    result = parse_resume(contents, file.filename)
    return result

# ========== MATCHING ==========
@app.get("/match/{user_id}", response_model=List[MatchResult])
async def match(user_id: int, use_claude: bool = True, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    results = await match_opportunities(db, user_id, use_claude=use_claude)
    return results

# ========== APPLICATIONS ==========
@app.post("/applications", response_model=ApplicationOut)
def create_application(app_data: ApplicationCreate, user_id: int, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    opp = db.query(Opportunity).filter(Opportunity.id == app_data.opportunity_id).first()
    if not opp:
        raise HTTPException(status_code=404, detail="Opportunity not found")

    db_app = Application(
        user_id=user_id,
        opportunity_id=app_data.opportunity_id,
        status=app_data.status,
        notes=app_data.notes
    )
    if app_data.status == "applied":
        db_app.applied_at = datetime.utcnow()

    db.add(db_app)
    db.commit()
    db.refresh(db_app)
    return db_app

@app.get("/applications/{user_id}", response_model=List[ApplicationOut])
def list_applications(user_id: int, db: Session = Depends(get_db)):
    return db.query(Application).filter(Application.user_id == user_id).all()

@app.patch("/applications/{app_id}")
def update_application(app_id: int, status: str, notes: Optional[str] = None, db: Session = Depends(get_db)):
    app = db.query(Application).filter(Application.id == app_id).first()
    if not app:
        raise HTTPException(status_code=404, detail="Application not found")
    app.status = status
    if notes:
        app.notes = notes
    if status == "applied" and not app.applied_at:
        app.applied_at = datetime.utcnow()
    db.commit()
    return {"id": app_id, "status": status}

# ========== SEARCH (Live Augmentation Placeholder) ==========
@app.get("/search")
async def search_opportunities(q: str, db: Session = Depends(get_db)):
    """
    On-demand search endpoint. Currently searches local DB.
    In production, this can call a search API (Claude with web search, SerpAPI, etc.)
    to pull fresh results and merge with seed DB.
    """
    results = db.query(Opportunity).filter(
        Opportunity.title.ilike(f"%{q}%") |
        Opportunity.description.ilike(f"%{q}%") |
        Opportunity.tags.contains([q])
    ).all()
    return {
        "query": q,
        "source": "local_db",
        "results": results,
        "note": "Live web search augmentation can be added here via Claude/SerpAPI integration"
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
