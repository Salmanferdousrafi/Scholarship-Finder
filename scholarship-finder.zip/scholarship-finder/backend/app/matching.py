import os
from typing import List
from sqlalchemy.orm import Session
from app.models import Opportunity, User
from app.schemas import MatchResult

# Try to use Anthropic if key available, otherwise use local scoring
ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY")

def local_score_opportunity(user: User, opp: Opportunity) -> tuple[float, str, List[str]]:
    """Simple rule-based scoring as fallback when Claude is unavailable."""
    score = 50.0
    factors = []

    # Degree level match
    if user.degree_level in opp.degree_levels:
        score += 20
        factors.append(f"Your {user.degree_level} level matches this opportunity")

    # Field match
    if user.field_of_study and (user.field_of_study.lower() in opp.field.lower() or opp.field.lower() == "any"):
        score += 15
        factors.append(f"Field match: {user.field_of_study}")

    # Country eligibility
    if user.country and (user.country in opp.countries or "All" in opp.countries):
        score += 10
        factors.append(f"Eligible from {user.country}")

    # Budget need
    if user.budget_need and opp.amount:
        score += 10
        factors.append("Fully funded — matches your financial need")

    # Skills overlap
    if user.skills and opp.tags:
        skill_matches = set(s.lower() for s in user.skills) & set(t.lower() for t in opp.tags)
        if skill_matches:
            score += min(len(skill_matches) * 5, 15)
            factors.append(f"Skill overlap: {', '.join(skill_matches)}")

    # Deadline proximity (if within window)
    from datetime import datetime
    if opp.deadline and user.deadline_window_months:
        months_until = (opp.deadline - datetime.utcnow()).days / 30
        if 0 < months_until <= user.deadline_window_months:
            score += 5
            factors.append(f"Deadline within your {user.deadline_window_months}-month window")

    score = min(score, 100)

    explanation = f"This {opp.type} at {opp.organization} scores {score:.0f}% based on your profile."
    if factors:
        explanation += " Key reasons: " + "; ".join(factors) + "."

    return score, explanation, factors

async def score_with_claude(user: User, opp: Opportunity) -> tuple[float, str, List[str]]:
    """Use Claude to score fit when API key is available."""
    try:
        import anthropic
        client = anthropic.AsyncAnthropic(api_key=ANTHROPIC_API_KEY)

        prompt = f"""You are a scholarship/internship matching assistant. Score how well this opportunity fits the applicant.

Applicant Profile:
- Name: {user.name}
- Field: {user.field_of_study}
- Degree Level: {user.degree_level}
- Country: {user.country}
- GPA: {user.gpa or 'Not provided'}
- Skills: {', '.join(user.skills) if user.skills else 'None listed'}
- Experience: {user.experience or 'Not provided'}
- Needs funding: {user.budget_need}
- Deadline window: {user.deadline_window_months} months

Opportunity:
- Title: {opp.title}
- Organization: {opp.organization}
- Type: {opp.type}
- Field: {opp.field}
- Degree Levels: {', '.join(opp.degree_levels)}
- Eligible Countries: {', '.join(opp.countries)}
- Amount: {opp.amount or 'Not specified'}
- Deadline: {opp.deadline.strftime('%Y-%m-%d') if opp.deadline else 'Not specified'}
- Description: {opp.description}
- Requirements: {opp.requirements or 'Not specified'}

Respond ONLY in this JSON format:
{{"score": <number 0-100>, "explanation": "<2-3 sentence explanation>", "key_fit_factors": ["<factor 1>", "<factor 2>", "<factor 3>"]}}
"""

        response = await client.messages.create(
            model="claude-3-5-sonnet-20241022",
            max_tokens=500,
            messages=[{"role": "user", "content": prompt}]
        )

        import json
        content = response.content[0].text
        # Extract JSON from possible markdown
        if "```json" in content:
            content = content.split("```json")[1].split("```")[0]
        elif "```" in content:
            content = content.split("```")[1].split("```")[0]

        result = json.loads(content.strip())
        return result["score"], result["explanation"], result["key_fit_factors"]
    except Exception as e:
        # Fallback to local scoring
        return local_score_opportunity(user, opp)

async def match_opportunities(db: Session, user_id: int, use_claude: bool = True) -> List[MatchResult]:
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        return []

    opportunities = db.query(Opportunity).all()
    results = []

    for opp in opportunities:
        if use_claude and ANTHROPIC_API_KEY:
            score, explanation, factors = await score_with_claude(user, opp)
        else:
            score, explanation, factors = local_score_opportunity(user, opp)

        results.append(MatchResult(
            opportunity=opp,
            score=score,
            explanation=explanation,
            key_fit_factors=factors
        ))

    # Sort by score descending
    results.sort(key=lambda x: x.score, reverse=True)
    return results
