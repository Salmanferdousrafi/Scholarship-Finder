import re
from typing import List, Optional
from PyPDF2 import PdfReader
from docx import Document
from app.schemas import ResumeParseOut

def extract_text_from_pdf(file_bytes: bytes) -> str:
    try:
        reader = PdfReader(file_bytes)
        text = ""
        for page in reader.pages:
            text += page.extract_text() or ""
        return text
    except Exception:
        return ""

def extract_text_from_docx(file_bytes: bytes) -> str:
    try:
        doc = Document(file_bytes)
        return "\n".join([para.text for para in doc.paragraphs])
    except Exception:
        return ""

def parse_resume(file_bytes: bytes, filename: str) -> ResumeParseOut:
    text = ""
    if filename.lower().endswith(".pdf"):
        text = extract_text_from_pdf(file_bytes)
    elif filename.lower().endswith(".docx"):
        text = extract_text_from_docx(file_bytes)
    else:
        text = file_bytes.decode("utf-8", errors="ignore")

    text = text.strip()
    if not text:
        return ResumeParseOut(raw_text="", skills=[])

    # Simple heuristic extraction (no LLM needed for basic parsing)
    name = None
    first_lines = [l.strip() for l in text.split("\n") if l.strip()][:3]
    if first_lines:
        name = first_lines[0]

    # GPA extraction
    gpa = None
    gpa_patterns = [
        r"GPA[:\s]+([0-4]\.\d{1,2})",
        r"Grade Point Average[:\s]+([0-4]\.\d{1,2})",
        r"CGPA[:\s]+([0-4]\.\d{1,2})",
        r"([0-4]\.\d{1,2})\s*/\s*4\.0"
    ]
    for pattern in gpa_patterns:
        match = re.search(pattern, text, re.IGNORECASE)
        if match:
            try:
                val = float(match.group(1))
                if 0 <= val <= 4.0:
                    gpa = val
                    break
            except ValueError:
                continue

    # Skills extraction (common tech/research skills)
    skill_keywords = [
        "python", "java", "c++", "javascript", "typescript", "react", "node", "sql",
        "machine learning", "deep learning", "tensorflow", "pytorch", "pandas", "numpy",
        "data analysis", "statistics", "matlab", "r programming", "latex",
        "research", "publication", "lab", "experiment", "thesis",
        "leadership", "teamwork", "communication", "project management",
        "biology", "chemistry", "physics", "mathematics", "economics",
        "cad", "solidworks", "arduino", " raspberry pi", "linux"
    ]
    text_lower = text.lower()
    skills = [kw for kw in skill_keywords if kw in text_lower]

    # Degree level inference
    degree_level = None
    degree_patterns = {
        "phd": ["phd", "ph.d", "doctorate", "doctoral"],
        "masters": ["master", "ms ", "m.s", "ma ", "m.a", "mba", "msc", "m.sc"],
        "undergrad": ["bachelor", "bs ", "b.s", "ba ", "b.a", "undergraduate"],
        "high_school": ["high school", "secondary school"]
    }
    for level, keywords in degree_patterns.items():
        if any(kw in text_lower for kw in keywords):
            degree_level = level
            break

    # Field inference
    field = None
    field_patterns = {
        "Computer Science": ["computer science", "software engineering", "cs ", "programming"],
        "Engineering": ["engineering", "mechanical", "electrical", "civil"],
        "Biology": ["biology", "biochemistry", "biotech", "biomedical"],
        "Physics": ["physics", "quantum", "particle physics"],
        "Mathematics": ["mathematics", "math", "statistics", "applied math"],
        "Economics": ["economics", "finance", "economy"],
        "Data Science": ["data science", "data analysis", "analytics"],
    }
    for fld, keywords in field_patterns.items():
        if any(kw in text_lower for kw in keywords):
            field = fld
            break

    return ResumeParseOut(
        name=name,
        field_of_study=field,
        degree_level=degree_level,
        gpa=gpa,
        skills=skills,
        experience_summary=text[:500] + "..." if len(text) > 500 else text,
        raw_text=text
    )
