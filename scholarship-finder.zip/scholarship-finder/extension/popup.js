// AI Scholarship Finder - Chrome Extension Popup
// Communicates with FastAPI backend

let state = {
  apiBase: 'http://localhost:8000',
  userId: null,
  userProfile: null,
  matches: [],
  applications: [],
  currentTab: 'search'
}

// ===== INIT =====
chrome.storage.local.get(['apiBase', 'userId', 'userProfile'], (data) => {
  if (data.apiBase) state.apiBase = data.apiBase
  if (data.userId) state.userId = data.userId
  if (data.userProfile) state.userProfile = data.userProfile

  document.getElementById('api-base').value = state.apiBase
  renderProfile()

  if (state.userId) {
    loadMatches()
    loadApplications()
  }
})

// ===== API =====
async function api(method, path, body = null, isForm = false) {
  const url = `${state.apiBase}${path}`
  const opts = { method }
  if (!isForm && body) {
    opts.headers = { 'Content-Type': 'application/json' }
    opts.body = JSON.stringify(body)
  } else if (isForm && body) {
    opts.body = body
  }

  try {
    const res = await fetch(url, opts)
    if (!res.ok) {
      const err = await res.json().catch(() => ({}))
      throw new Error(err.detail || `HTTP ${res.status}`)
    }
    return await res.json()
  } catch (e) {
    showStatus(e.message, 'error')
    throw e
  }
}

// ===== TABS =====
document.querySelectorAll('.nav-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    const tab = btn.dataset.tab
    switchTab(tab)
  })
})

function switchTab(tab) {
  state.currentTab = tab
  document.querySelectorAll('.nav-btn').forEach(b => b.classList.toggle('active', b.dataset.tab === tab))

  document.getElementById('search-section').classList.toggle('hidden', tab !== 'search')
  document.getElementById('matches-section').classList.toggle('hidden', tab !== 'matches')
  document.getElementById('apps-section').classList.toggle('hidden', tab !== 'apps')
  document.getElementById('profile-section').classList.toggle('hidden', tab !== 'profile')

  if (tab === 'matches' && state.userId && !state.matches.length) loadMatches()
  if (tab === 'apps' && state.userId && !state.applications.length) loadApplications()
}

// ===== PROFILE =====
document.getElementById('btn-create-profile').addEventListener('click', () => {
  document.getElementById('profile-card').classList.add('hidden')
  document.getElementById('profile-form').classList.remove('hidden')
})

document.getElementById('btn-save-profile').addEventListener('click', async () => {
  const payload = {
    name: document.getElementById('p-name').value,
    email: document.getElementById('p-email').value,
    field_of_study: document.getElementById('p-field').value,
    degree_level: document.getElementById('p-degree').value,
    country: document.getElementById('p-country').value,
    gpa: document.getElementById('p-gpa').value ? parseFloat(document.getElementById('p-gpa').value) : null,
    skills: document.getElementById('p-skills').value.split(',').map(s => s.trim()).filter(Boolean),
    experience: document.getElementById('p-experience').value,
    budget_need: document.getElementById('p-budget').checked,
    deadline_window_months: parseInt(document.getElementById('p-window').value) || 12
  }

  try {
    let result
    if (state.userId) {
      result = await api('PUT', `/users/${state.userId}`, payload)
    } else {
      result = await api('POST', '/users', payload)
    }

    state.userId = result.id
    state.userProfile = result
    chrome.storage.local.set({ userId: result.id, userProfile: result })

    showStatus('Profile saved!', 'success')
    renderProfile()
    loadMatches()
    loadApplications()
    switchTab('matches')
  } catch (e) {
    // error already shown by api()
  }
})

function renderProfile() {
  const card = document.getElementById('profile-card')
  const form = document.getElementById('profile-form')

  if (!state.userProfile) {
    card.classList.remove('hidden')
    form.classList.add('hidden')
    return
  }

  card.classList.add('hidden')
  form.classList.remove('hidden')

  const p = state.userProfile
  document.getElementById('p-name').value = p.name || ''
  document.getElementById('p-email').value = p.email || ''
  document.getElementById('p-field').value = p.field_of_study || ''
  document.getElementById('p-degree').value = p.degree_level || 'undergrad'
  document.getElementById('p-country').value = p.country || ''
  document.getElementById('p-gpa').value = p.gpa || ''
  document.getElementById('p-skills').value = Array.isArray(p.skills) ? p.skills.join(', ') : ''
  document.getElementById('p-experience').value = p.experience || ''
  document.getElementById('p-budget').checked = p.budget_need || false
  document.getElementById('p-window').value = p.deadline_window_months || 12
}

// ===== SEARCH =====
document.getElementById('btn-search').addEventListener('click', async () => {
  const q = document.getElementById('search-input').value.trim()
  if (!q) return

  const container = document.getElementById('search-results')
  container.innerHTML = '<div class="loading"><div class="spinner"></div>Searching...</div>'

  try {
    const results = await api('GET', `/opportunities?search=${encodeURIComponent(q)}`)
    renderOpportunities(results, container)
  } catch (e) {
    container.innerHTML = '<div class="status-msg status-error">Search failed. Is backend running?</div>'
  }
})

function renderOpportunities(list, container) {
  if (!list.length) {
    container.innerHTML = '<div class="status-msg">No opportunities found.</div>'
    return
  }

  container.innerHTML = list.map(opp => `
    <div class="match-card">
      <div class="match-content" style="flex:1">
        <div style="display:flex;align-items:center;gap:6px;margin-bottom:4px">
          <span class="tag type-${opp.type}">${opp.type}</span>
          <span style="font-size:11px;color:#64748b">${opp.organization}</span>
        </div>
        <div class="match-title">${opp.title}</div>
        <div class="match-org">${opp.amount || 'Amount not specified'} · Deadline: ${opp.deadline ? new Date(opp.deadline).toLocaleDateString() : 'Rolling'}</div>
        <div class="match-desc">${opp.description.substring(0, 120)}...</div>
        <div class="match-actions">
          <a href="${opp.url}" target="_blank" class="btn btn-sm btn-secondary">View →</a>
          ${state.userId ? `<button class="btn btn-sm btn-primary" onclick="trackOpp(${opp.id}, this)">Track</button>` : ''}
        </div>
      </div>
    </div>
  `).join('')
}

// ===== MATCHES =====
async function loadMatches() {
  if (!state.userId) return
  const container = document.getElementById('matches-list')
  container.innerHTML = '<div class="loading"><div class="spinner"></div>Finding AI matches...</div>'

  try {
    const results = await api('GET', `/match/${state.userId}?use_claude=false`)
    state.matches = results
    renderMatches(results, container)
  } catch (e) {
    container.innerHTML = '<div class="status-msg status-error">Failed to load matches. Is backend running?</div>'
  }
}

function renderMatches(list, container) {
  if (!list.length) {
    container.innerHTML = '<div class="status-msg">No matches found. Update your profile.</div>'
    return
  }

  container.innerHTML = list.map(m => {
    const opp = m.opportunity
    const scoreClass = m.score >= 75 ? 'score-high' : m.score >= 50 ? 'score-mid' : 'score-low'
    return `
    <div class="match-card">
      <div class="score-badge ${scoreClass}">${Math.round(m.score)}</div>
      <div class="match-content">
        <div style="display:flex;align-items:center;gap:6px;margin-bottom:4px">
          <span class="tag type-${opp.type}">${opp.type}</span>
          <span style="font-size:11px;color:#64748b">${opp.organization}</span>
        </div>
        <div class="match-title">${opp.title}</div>
        <div class="match-org">${opp.amount || 'Amount not specified'} · Deadline: ${opp.deadline ? new Date(opp.deadline).toLocaleDateString() : 'Rolling'}</div>
        <div class="match-desc">${m.explanation}</div>
        ${m.key_fit_factors?.length ? `
        <div class="match-factors">
          ${m.key_fit_factors.map(f => `<span class="match-factor">✓ ${f}</span>`).join('')}
        </div>` : ''}
        <div class="match-actions">
          <a href="${opp.url}" target="_blank" class="btn btn-sm btn-secondary">View →</a>
          <button class="btn btn-sm btn-primary" onclick="trackOpp(${opp.id}, this)">Track</button>
        </div>
      </div>
    </div>
  `}).join('')
}

// ===== APPLICATIONS =====
async function loadApplications() {
  if (!state.userId) return
  const container = document.getElementById('apps-list')

  try {
    const apps = await api('GET', `/applications/${state.userId}`)
    state.applications = apps
    renderApps(apps, container)
  } catch (e) {
    container.innerHTML = '<div class="status-msg status-error">Failed to load applications.</div>'
  }
}

function renderApps(list, container) {
  if (!list.length) {
    container.innerHTML = '<div class="status-msg">No applications tracked yet.</div>'
    return
  }

  const colors = { interested: '#6366f1', applied: '#3b82f6', accepted: '#10b981', rejected: '#ef4444' }
  container.innerHTML = list.map(app => `
    <div class="app-item">
      <div class="app-dot" style="background:${colors[app.status] || '#94a3b8'}"></div>
      <div class="app-info">
        <div class="app-title">${app.opportunity.title}</div>
        <div class="app-meta">${app.opportunity.organization} · ${app.status}</div>
      </div>
      ${app.applied_at ? `<span style="font-size:11px;color:#64748b">${new Date(app.applied_at).toLocaleDateString()}</span>` : ''}
    </div>
  `).join('')
}

// ===== TRACKING =====
window.trackOpp = async function(oppId, btn) {
  if (!state.userId) {
    showStatus('Create a profile first', 'error')
    switchTab('profile')
    return
  }

  btn.disabled = true
  btn.textContent = '...'

  try {
    await api('POST', '/applications', { opportunity_id: oppId, status: 'interested' }, false, { user_id: state.userId })
    btn.textContent = 'Tracked ✓'
    btn.style.background = '#dcfce7'
    btn.style.color = '#166534'
    showStatus('Application tracked!', 'success')
    loadApplications()
  } catch (e) {
    btn.disabled = false
    btn.textContent = 'Track'
  }
}

// Fix: trackOpp needs to pass user_id as query param
// Override the api function for this specific case
async function trackOpp(oppId, btn) {
  if (!state.userId) {
    showStatus('Create a profile first', 'error')
    switchTab('profile')
    return
  }

  btn.disabled = true
  btn.textContent = '...'

  try {
    const url = `${state.apiBase}/applications?user_id=${state.userId}`
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ opportunity_id: oppId, status: 'interested' })
    })
    if (!res.ok) throw new Error('Failed')
    btn.textContent = 'Tracked ✓'
    btn.style.background = '#dcfce7'
    btn.style.color = '#166534'
    showStatus('Application tracked!', 'success')
    loadApplications()
  } catch (e) {
    btn.disabled = false
    btn.textContent = 'Track'
    showStatus('Already tracking or error', 'error')
  }
}
window.trackOpp = trackOpp

// ===== REFRESH =====
document.getElementById('btn-refresh').addEventListener('click', () => {
  state.matches = []
  loadMatches()
})

// ===== SETTINGS =====
document.getElementById('save-settings').addEventListener('click', () => {
  const base = document.getElementById('api-base').value.trim()
  if (base) {
    state.apiBase = base
    chrome.storage.local.set({ apiBase: base })
    showStatus('API URL saved', 'success')
  }
})

// ===== UTILS =====
function showStatus(msg, type) {
  // Remove old status
  document.querySelectorAll('.status-toast').forEach(el => el.remove())

  const toast = document.createElement('div')
  toast.className = `status-toast status-${type}`
  toast.textContent = msg
  toast.style.cssText = `
    position: fixed;
    top: 12px;
    left: 50%;
    transform: translateX(-50%);
    padding: 8px 16px;
    border-radius: 20px;
    font-size: 13px;
    font-weight: 600;
    z-index: 1000;
    animation: fadeIn 0.3s;
    ${type === 'error' ? 'background:#fee2e2;color:#991b1b;' : 'background:#dcfce7;color:#166534;'}
  `
  document.body.appendChild(toast)
  setTimeout(() => toast.remove(), 3000)
}

// Add fadeIn animation
const style = document.createElement('style')
style.textContent = `
  @keyframes fadeIn {
    from { opacity: 0; transform: translateX(-50%) translateY(-10px); }
    to { opacity: 1; transform: translateX(-50%) translateY(0); }
  }
`
document.head.appendChild(style)
