chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.set({
    apiBase: 'http://localhost:8000',
    userId: null,
    userProfile: null
  })
  console.log('AI Scholarship Finder installed')
})

chrome.action.onClicked.addListener((tab) => {
  // Fallback if popup fails
  chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: () => {
      window.open('http://localhost:3000', '_blank')
    }
  })
})
