import React, { useState, useEffect } from 'react'
import { BrowserRouter, Routes, Route, NavLink } from 'react-router-dom'
import ProfileForm from './components/ProfileForm.jsx'
import ResumeUploader from './components/ResumeUploader.jsx'
import MatchCard from './components/MatchCard.jsx'
import SearchBar from './components/SearchBar.jsx'
import ApplicationsList from './components/ApplicationsList.jsx'
import { getMatches, listApplications, getUser } from './api.jsx'

function HomePage() {
  const [user, setUser] = useState(null)
  const [matches, setMatches] = useState([])
  const [loading, setLoading] = useState(false)
  const [showProfile, setShowProfile] = useState(false)

  const userId = localStorage.getItem('userId')

  useEffect(() => {
    if (userId) {
      getUser(userId).then(setUser).catch(() => localStorage.removeItem('userId'))
    }
  }, [userId])

  const handleGetMatches = async () => {
    if (!userId) {
      setShowProfile(true)
      return
    }
    setLoading(true)
    try {
      const data = await getMatches(userId, false) // local scoring for speed
      setMatches(data)
    } catch (err) {
      alert('Failed to get matches')
    } finally {
      setLoading(false)
    }
  }

  const handleParsed = (parsed) => {
    // Pre-fill profile form with parsed data
    if (parsed) {
      const merged = {
        ...parsed,
        skills: parsed.skills?.join(', ') || '',
        gpa: parsed.gpa || '',
        email: user?.email || '',
        name: parsed.name || user?.name || '',
      }
      setUser(merged)
      setShowProfile(true)
    }
  }

  return (
    <div className="container">
      <header style={{ textAlign: 'center', padding: '32px 0 24px' }}>
        <div style={{
          width: '56px',
          height: '56px',
          borderRadius: '16px',
          background: 'linear-gradient(135deg, var(--primary), var(--secondary))',
          margin: '0 auto 16px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center'
        }}>
          <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2">
            <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" />
            <polyline points="22 4 12 14.01 9 11.01" />
          </svg>
        </div>
        <h1 style={{ fontSize: '24px', fontWeight: 800, marginBottom: '6px' }}>
          AI Scholarship Finder
        </h1>
        <p style={{ color: 'var(--text-light)', fontSize: '15px' }}>
          Find scholarships, internships & fellowships matched to you
        </p>
      </header>

      <SearchBar onResults={setMatches} />

      {!userId && (
        <>
          <ResumeUploader onParsed={handleParsed} />
          {showProfile && <ProfileForm user={user} onSave={(u) => {
            localStorage.setItem('userId', u.id)
            setUser(u)
            setShowProfile(false)
          }} />}
          {!showProfile && (
            <button className="btn btn-primary" onClick={() => setShowProfile(true)}>
              Create Profile to Get Matches
            </button>
          )}
        </>
      )}

      {userId && (
        <div style={{ display: 'flex', gap: '12px', marginBottom: '16px' }}>
          <button className="btn btn-primary" onClick={handleGetMatches} disabled={loading}>
            {loading ? 'Finding matches...' : 'Get AI Matches'}
          </button>
          <button className="btn btn-secondary" onClick={() => setShowProfile(!showProfile)}>
            {showProfile ? 'Hide Profile' : 'Edit Profile'}
          </button>
        </div>
      )}

      {showProfile && userId && (
        <ProfileForm user={user} onSave={(u) => { setUser(u); setShowProfile(false) }} />
      )}

      {matches.length > 0 && (
        <div>
          <h2 style={{ fontSize: '18px', fontWeight: 700, marginBottom: '16px' }}>
            {matches.length} Match{matches.length !== 1 ? 'es' : ''}
          </h2>
          {matches.map((match, i) => (
            <MatchCard key={i} match={match} userId={userId} />
          ))}
        </div>
      )}
    </div>
  )
}

function ApplicationsPage() {
  const [apps, setApps] = useState([])
  const userId = localStorage.getItem('userId')

  useEffect(() => {
    if (userId) {
      listApplications(userId).then(setApps)
    }
  }, [userId])

  return (
    <div className="container">
      <ApplicationsList applications={apps} />
    </div>
  )
}

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/applications" element={<ApplicationsPage />} />
      </Routes>
      <nav style={{
        position: 'fixed',
        bottom: 0,
        left: 0,
        right: 0,
        background: 'white',
        borderTop: '1px solid var(--border)',
        display: 'flex',
        justifyContent: 'space-around',
        padding: '8px 0',
        zIndex: 100
      }}>
        <NavLink to="/" style={({ isActive }) => ({
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          gap: '4px',
          fontSize: '11px',
          color: isActive ? 'var(--primary)' : 'var(--text-light)',
          textDecoration: 'none',
          fontWeight: isActive ? 600 : 400
        })}>
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" />
            <polyline points="9 22 9 12 15 12 15 22" />
          </svg>
          Discover
        </NavLink>
        <NavLink to="/applications" style={({ isActive }) => ({
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          gap: '4px',
          fontSize: '11px',
          color: isActive ? 'var(--primary)' : 'var(--text-light)',
          textDecoration: 'none',
          fontWeight: isActive ? 600 : 400
        })}>
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
          </svg>
          Tracking
        </NavLink>
      </nav>
      <div style={{ height: '60px' }} />
    </BrowserRouter>
  )
}

export default App
