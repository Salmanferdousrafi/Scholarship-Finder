import React, { useState } from 'react'
import { createApplication } from '../api.jsx'

export default function MatchCard({ match, userId, onTrack }) {
  const { opportunity, score, explanation, key_fit_factors } = match
  const [tracked, setTracked] = useState(false)

  const getScoreClass = () => {
    if (score >= 75) return 'score-high'
    if (score >= 50) return 'score-mid'
    return 'score-low'
  }

  const getTypeClass = () => `type-${opportunity.type}`

  const handleTrack = async () => {
    try {
      await createApplication(userId, { opportunity_id: opportunity.id, status: 'interested' })
      setTracked(true)
      onTrack?.()
    } catch (err) {
      alert('Already tracking this opportunity')
    }
  }

  const deadline = opportunity.deadline
    ? new Date(opportunity.deadline).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })
    : 'Rolling'

  return (
    <div className="card" style={{ display: 'flex', gap: '16px', alignItems: 'flex-start' }}>
      <div className={`score-badge ${getScoreClass()}`}>
        {Math.round(score)}
      </div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flexWrap: 'wrap', marginBottom: '6px' }}>
          <span className={`tag ${getTypeClass()}`}>{opportunity.type}</span>
          <span style={{ fontSize: '13px', color: 'var(--text-light)' }}>{opportunity.organization}</span>
        </div>
        <h3 style={{ fontSize: '16px', fontWeight: 700, marginBottom: '4px', lineHeight: 1.3 }}>
          {opportunity.title}
        </h3>
        <p style={{ fontSize: '13px', color: 'var(--text-light)', marginBottom: '8px' }}>
          {opportunity.amount} · Deadline: {deadline}
        </p>
        <p style={{ fontSize: '14px', lineHeight: 1.5, marginBottom: '12px', color: 'var(--text)' }}>
          {explanation}
        </p>
        {key_fit_factors?.length > 0 && (
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px', marginBottom: '12px' }}>
            {key_fit_factors.map((f, i) => (
              <span key={i} style={{
                fontSize: '12px',
                padding: '4px 10px',
                background: '#f1f5f9',
                borderRadius: '20px',
                color: '#475569'
              }}>
                ✓ {f}
              </span>
            ))}
          </div>
        )}
        <div style={{ display: 'flex', gap: '8px' }}>
          <a href={opportunity.url} target="_blank" rel="noopener noreferrer" className="btn btn-secondary" style={{ flex: 1, padding: '8px 12px', fontSize: '13px' }}>
            View Details →
          </a>
          <button
            className="btn"
            onClick={handleTrack}
            disabled={tracked}
            style={{
              flex: 1,
              padding: '8px 12px',
              fontSize: '13px',
              background: tracked ? '#dcfce7' : 'var(--primary)',
              color: tracked ? '#166534' : 'white'
            }}
          >
            {tracked ? 'Tracking ✓' : 'Track Application'}
          </button>
        </div>
      </div>
    </div>
  )
}
