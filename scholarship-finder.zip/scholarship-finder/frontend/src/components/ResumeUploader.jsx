import React, { useState } from 'react'
import { parseResume } from '../api.jsx'

export default function ResumeUploader({ onParsed }) {
  const [file, setFile] = useState(null)
  const [parsing, setParsing] = useState(false)
  const [parsed, setParsed] = useState(null)

  const handleFile = async (e) => {
    const f = e.target.files[0]
    if (!f) return
    setFile(f)
    setParsing(true)
    try {
      const data = await parseResume(f)
      setParsed(data)
      onParsed?.(data)
    } catch (err) {
      alert('Failed to parse resume')
    } finally {
      setParsing(false)
    }
  }

  return (
    <div className="card">
      <h3 style={{ fontSize: '16px', fontWeight: 600, marginBottom: '12px' }}>
        Or upload your resume
      </h3>
      <label style={{
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '32px 20px',
        border: '2px dashed var(--border)',
        borderRadius: 'var(--radius)',
        cursor: 'pointer',
        transition: 'all 0.2s',
        background: parsed ? '#f0fdf4' : undefined,
        borderColor: parsed ? '#86efac' : undefined
      }}>
        <input type="file" accept=".pdf,.docx,.txt" onChange={handleFile} style={{ display: 'none' }} />
        {parsing ? (
          <><div className="spinner" /><span>Parsing resume...</span></>
        ) : parsed ? (
          <>
            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#10b981" strokeWidth="2">
              <polyline points="20 6 9 17 4 12" />
            </svg>
            <span style={{ color: '#059669', fontWeight: 600, marginTop: '8px' }}>
              Parsed: {parsed.name || 'Resume'}
            </span>
            {parsed.field_of_study && <span style={{ fontSize: '13px', color: 'var(--text-light)', marginTop: '4px' }}>{parsed.field_of_study} · {parsed.degree_level}</span>}
          </>
        ) : (
          <>
            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="var(--text-light)" strokeWidth="1.5">
              <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
              <polyline points="17 8 12 3 7 8" />
              <line x1="12" y1="3" x2="12" y2="15" />
            </svg>
            <span style={{ marginTop: '8px', color: 'var(--text-light)' }}>
              Drop PDF, DOCX, or TXT
            </span>
          </>
        )}
      </label>
      {parsed && (
        <div style={{ marginTop: '16px', fontSize: '13px', color: 'var(--text-light)' }}>
          {parsed.skills?.length > 0 && <p><strong>Skills detected:</strong> {parsed.skills.join(', ')}</p>}
          {parsed.gpa && <p><strong>GPA:</strong> {parsed.gpa}</p>}
        </div>
      )}
    </div>
  )
}
