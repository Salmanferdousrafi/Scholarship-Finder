import React, { useState } from 'react'
import { searchOpportunities } from '../api.jsx'

export default function SearchBar({ onResults }) {
  const [query, setQuery] = useState('')
  const [loading, setLoading] = useState(false)

  const handleSearch = async (e) => {
    e.preventDefault()
    if (!query.trim()) return
    setLoading(true)
    try {
      const data = await searchOpportunities(query)
      onResults?.(data.results || [])
    } catch (err) {
      alert('Search failed')
    } finally {
      setLoading(false)
    }
  }

  return (
    <form onSubmit={handleSearch} className="card" style={{ padding: '12px 16px' }}>
      <div style={{ display: 'flex', gap: '8px' }}>
        <input
          className="input"
          placeholder="Search scholarships, internships, fellowships..."
          value={query}
          onChange={e => setQuery(e.target.value)}
          style={{ flex: 1 }}
        />
        <button className="btn btn-primary" type="submit" disabled={loading} style={{ width: 'auto', padding: '10px 20px' }}>
          {loading ? '...' : 'Search'}
        </button>
      </div>
    </form>
  )
}
