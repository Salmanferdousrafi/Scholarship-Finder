import React, { useState, useEffect } from 'react'
import { createUser, updateUser } from '../api.jsx'

const DEGREE_LEVELS = [
  { value: 'high_school', label: 'High School' },
  { value: 'undergrad', label: 'Undergraduate' },
  { value: 'masters', label: "Master's" },
  { value: 'phd', label: 'PhD / Doctorate' },
  { value: 'postdoc', label: 'Postdoc' },
]

const FIELDS = [
  'Computer Science', 'Engineering', 'Biology', 'Physics',
  'Mathematics', 'Economics', 'Data Science', 'Medicine',
  'Chemistry', 'Psychology', 'Political Science', 'Any / Other'
]

export default function ProfileForm({ user, onSave }) {
  const [form, setForm] = useState({
    email: '',
    name: '',
    field_of_study: '',
    degree_level: 'undergrad',
    country: '',
    gpa: '',
    skills: '',
    experience: '',
    budget_need: false,
    deadline_window_months: 12,
  })
  const [loading, setLoading] = useState(false)
  const [saved, setSaved] = useState(false)

  useEffect(() => {
    if (user) {
      setForm({
        ...user,
        skills: Array.isArray(user.skills) ? user.skills.join(', ') : user.skills || '',
        gpa: user.gpa || '',
      })
    }
  }, [user])

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target
    setForm(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }))
    setSaved(false)
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)
    try {
      const payload = {
        ...form,
        gpa: form.gpa ? parseFloat(form.gpa) : null,
        skills: form.skills.split(',').map(s => s.trim()).filter(Boolean),
      }
      let result
      if (user?.id) {
        result = await updateUser(user.id, payload)
      } else {
        result = await createUser(payload)
      }
      setSaved(true)
      onSave?.(result)
    } catch (err) {
      alert(err.response?.data?.detail || 'Error saving profile')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="card">
      <h2 style={{ fontSize: '20px', fontWeight: 700, marginBottom: '20px' }}>
        {user ? 'Edit Profile' : 'Create Your Profile'}
      </h2>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label className="label">Full Name</label>
          <input className="input" name="name" value={form.name} onChange={handleChange} required />
        </div>
        <div className="form-group">
          <label className="label">Email</label>
          <input className="input" name="email" type="email" value={form.email} onChange={handleChange} required />
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
          <div className="form-group">
            <label className="label">Field of Study</label>
            <select className="select" name="field_of_study" value={form.field_of_study} onChange={handleChange} required>
              <option value="">Select...</option>
              {FIELDS.map(f => <option key={f} value={f}>{f}</option>)}
            </select>
          </div>
          <div className="form-group">
            <label className="label">Degree Level</label>
            <select className="select" name="degree_level" value={form.degree_level} onChange={handleChange} required>
              {DEGREE_LEVELS.map(d => <option key={d.value} value={d.value}>{d.label}</option>)}
            </select>
          </div>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
          <div className="form-group">
            <label className="label">Country</label>
            <input className="input" name="country" placeholder="e.g. USA, India, Germany" value={form.country} onChange={handleChange} required />
          </div>
          <div className="form-group">
            <label className="label">GPA (0-4.0)</label>
            <input className="input" name="gpa" type="number" step="0.01" min="0" max="4" placeholder="Optional" value={form.gpa} onChange={handleChange} />
          </div>
        </div>
        <div className="form-group">
          <label className="label">Skills (comma separated)</label>
          <input className="input" name="skills" placeholder="Python, research, leadership, machine learning..." value={form.skills} onChange={handleChange} />
        </div>
        <div className="form-group">
          <label className="label">Experience / Bio</label>
          <textarea className="textarea" name="experience" rows={3} placeholder="Brief background, research interests, achievements..." value={form.experience} onChange={handleChange} />
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px', alignItems: 'center' }}>
          <label style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '14px', cursor: 'pointer' }}>
            <input type="checkbox" name="budget_need" checked={form.budget_need} onChange={handleChange} />
            Need financial support
          </label>
          <div className="form-group" style={{ margin: 0 }}>
            <label className="label">Deadline Window (months)</label>
            <input className="input" name="deadline_window_months" type="number" min="1" max="36" value={form.deadline_window_months} onChange={handleChange} />
          </div>
        </div>
        <button className="btn btn-primary" type="submit" disabled={loading} style={{ marginTop: '20px' }}>
          {loading ? 'Saving...' : saved ? 'Saved ✓' : user ? 'Update Profile' : 'Create Profile'}
        </button>
      </form>
    </div>
  )
}
