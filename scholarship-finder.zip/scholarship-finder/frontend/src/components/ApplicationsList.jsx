import React from 'react'

const STATUS_COLORS = {
  interested: '#6366f1',
  applied: '#3b82f6',
  accepted: '#10b981',
  rejected: '#ef4444'
}

export default function ApplicationsList({ applications }) {
  if (!applications?.length) {
    return (
      <div className="empty-state">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
          <path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
        </svg>
        <p>No applications tracked yet</p>
        <p style={{ fontSize: '13px', marginTop: '4px' }}>Find matches and click "Track Application" to start</p>
      </div>
    )
  }

  return (
    <div>
      <h2 style={{ fontSize: '18px', fontWeight: 700, marginBottom: '16px' }}>Your Applications</h2>
      {applications.map(app => (
        <div key={app.id} className="card" style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          <div style={{
            width: '10px',
            height: '10px',
            borderRadius: '50%',
            background: STATUS_COLORS[app.status] || '#94a3b8',
            flexShrink: 0
          }} />
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontWeight: 600, fontSize: '15px' }}>{app.opportunity.title}</div>
            <div style={{ fontSize: '13px', color: 'var(--text-light)' }}>
              {app.opportunity.organization} · {app.status}
            </div>
          </div>
          {app.applied_at && (
            <span style={{ fontSize: '12px', color: 'var(--text-light)' }}>
              Applied {new Date(app.applied_at).toLocaleDateString()}
            </span>
          )}
        </div>
      ))}
    </div>
  )
}
