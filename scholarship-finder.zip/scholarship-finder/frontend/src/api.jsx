import axios from 'axios'

const API_BASE = import.meta.env.VITE_API_URL || '/api'

const api = axios.create({
  baseURL: API_BASE,
  headers: { 'Content-Type': 'application/json' }
})

export const createUser = (data) => api.post('/users', data).then(r => r.data)
export const getUser = (id) => api.get(`/users/${id}`).then(r => r.data)
export const updateUser = (id, data) => api.put(`/users/${id}`, data).then(r => r.data)

export const listOpportunities = (params) => api.get('/opportunities', { params }).then(r => r.data)
export const getOpportunity = (id) => api.get(`/opportunities/${id}`).then(r => r.data)

export const parseResume = (file) => {
  const form = new FormData()
  form.append('file', file)
  return api.post('/parse-resume', form, {
    headers: { 'Content-Type': 'multipart/form-data' }
  }).then(r => r.data)
}

export const getMatches = (userId, useClaude = true) =>
  api.get(`/match/${userId}?use_claude=${useClaude}`).then(r => r.data)

export const createApplication = (userId, data) =>
  api.post('/applications', data, { params: { user_id: userId } }).then(r => r.data)

export const listApplications = (userId) =>
  api.get(`/applications/${userId}`).then(r => r.data)

export const searchOpportunities = (q) =>
  api.get('/search', { params: { q } }).then(r => r.data)

export default api
